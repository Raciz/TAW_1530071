<?php
define('DB_HOST', '');
define('DB_DATABASE', '');
define('DB_USER', '');
define('DB_PASSWORD', '');