<?php
//variabes para realizar la conexion a la base de datos
$host = "localhost";
$user = "root";
$pass = "";
$db = "alumnos";
?>